// This file should run with: node lab3.js

// MOCK DATA

// MODELS

// BUILD THE MONGO URI CONNECTION STRING

// CONNECT TO MONGO DB

// HELPER FUNCTION TO FIND MATCH BASED ON idx

// SCRIPT TO CLEAN, INSERT AND QUERY
const execScript = async () => {
    // clean any existing data in our database
    // iterate and insert users
    // iterate and insert snippets
    // iterate and insert bookmarks
    // query to get a user with snippets and bookmarks
    // query to get a snippet with bookmarks
    // close the connection to mongo db
};
execScript();
